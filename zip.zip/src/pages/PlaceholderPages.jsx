import React from 'react'
import SectionTag from '../components/SectionTag'

const placeholderPages = {
  news: { tag: 'News', title: 'Engineering Insights & Updates', subtitle: 'Stay up to date with the latest from Impaqwerk — insights, project highlights, and industry news.' },
  partners: { tag: 'Partners', title: 'Our Trusted Partners', subtitle: 'We collaborate with industry-leading companies to deliver the best engineering talent and solutions.' },
  contact: { tag: 'Contact Us', title: "Let's Start a Conversation", subtitle: "Reach out to us to discuss your engineering capacity needs. We'll get back to you within 24 hours." },
}

export function News() {
  return <PlaceholderPage {...placeholderPages.news} />
}
export function Partners() {
  return <PlaceholderPage {...placeholderPages.partners} />
}
export function Contact() {
  return (
    <div>
      <section className="bg-white py-16 lg:py-24">
        <div className="max-w-7xl mx-auto px-4 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-14 items-start">
            <div>
              <SectionTag>Contact Us</SectionTag>
              <h1 className="text-4xl lg:text-5xl font-extrabold text-gray-900 leading-tight mb-4">
                Let's Start a Conversation
              </h1>
              <div className="w-12 h-1 bg-red-600 mb-5" />
              <p className="text-sm text-gray-600 leading-relaxed mb-8">
                Reach out to us to discuss your engineering capacity needs. We'll get back to you within 24 hours.
              </p>
              <div className="space-y-4 text-sm text-gray-600">
                <div><strong className="text-gray-900">Address:</strong> Office no - Q34, 4th Floor, A Building, City Vista Downtown, Fountain Road, Kharadi, Pune, Maharashtra, 411014, India</div>
                <div><strong className="text-gray-900">Phone:</strong> +91 20 1234 5678</div>
                <div><strong className="text-gray-900">Email:</strong> info@impaqwerk.com</div>
              </div>
            </div>
            <div className="bg-gray-50 rounded-xl p-8">
              <h2 className="text-xl font-bold text-gray-900 mb-6">Send Us a Message</h2>
              <form className="space-y-4" onSubmit={(e) => e.preventDefault()}>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1.5">First Name</label>
                    <input type="text" className="w-full border border-gray-200 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:border-red-400 transition-colors" placeholder="John" />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1.5">Last Name</label>
                    <input type="text" className="w-full border border-gray-200 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:border-red-400 transition-colors" placeholder="Doe" />
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1.5">Email</label>
                  <input type="email" className="w-full border border-gray-200 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:border-red-400 transition-colors" placeholder="john@company.com" />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1.5">Company</label>
                  <input type="text" className="w-full border border-gray-200 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:border-red-400 transition-colors" placeholder="Your company name" />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1.5">Message</label>
                  <textarea rows={4} className="w-full border border-gray-200 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:border-red-400 transition-colors resize-none" placeholder="Tell us about your engineering needs..." />
                </div>
                <button
                  type="submit"
                  className="w-full bg-red-600 hover:bg-red-700 text-white text-sm font-semibold py-3 rounded-lg transition-all duration-200 hover:scale-[1.02]"
                >
                  Send Message
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

function PlaceholderPage({ tag, title, subtitle }) {
  return (
    <div>
      <section className="bg-white py-20 lg:py-32">
        <div className="max-w-7xl mx-auto px-4 lg:px-8 text-center">
          <SectionTag>{tag}</SectionTag>
          <h1 className="text-4xl lg:text-5xl font-extrabold text-gray-900 mb-4">{title}</h1>
          <div className="w-12 h-1 bg-red-600 mx-auto mb-5" />
          <p className="text-sm lg:text-base text-gray-500 max-w-lg mx-auto">{subtitle}</p>
          <p className="mt-8 text-sm text-gray-400">Content coming soon.</p>
        </div>
      </section>
    </div>
  )
}
