import React from 'react'
import { Link } from 'react-router-dom'
import {
  Users, FileText, Settings, BadgeCheck, TrendingUp
} from 'lucide-react'
import SectionTag from '../components/SectionTag'
import SectionHeading from '../components/SectionHeading'
import ProcessStep from '../components/ProcessStep'

const steps = [
  { icon: Users, title: 'Understand', description: 'We understand your requirements and project goals.' },
  { icon: BadgeCheck, title: 'Select', description: 'We find and present the right engineering talent for your needs.' },
  { icon: FileText, title: 'Onboard', description: 'Smooth onboarding and tool access setup.' },
  { icon: Settings, title: 'Collaborate', description: 'Engineers work as part of your extended team.' },
  { icon: TrendingUp, title: 'Deliver & Grow', description: 'Consistent delivery & continuous improvement to help you grow.' },
]

export default function Process() {
  return (
    <div>
      <section className="relative bg-white overflow-hidden min-h-[380px]">
        <div className="max-w-7xl mx-auto px-4 lg:px-8 py-16 lg:py-24">
          <SectionTag>How It Works</SectionTag>
          <h1 className="text-4xl lg:text-5xl font-extrabold text-gray-900 leading-tight mb-4">
            Simple Process.<br />Strong Results.
          </h1>
          <div className="w-12 h-1 bg-red-600 mb-5" />
          <p className="text-sm lg:text-base text-gray-600 leading-relaxed max-w-lg">
            Our streamlined 5-step process ensures that you get the right engineer, integrated into your team, delivering results from day one.
          </p>
        </div>
      </section>
      <section className="py-16 lg:py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-5 gap-8 lg:gap-4">
            {steps.map((step, i) => (
              <ProcessStep key={i} {...step} step={i + 1} isLast={i === steps.length - 1} />
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}
