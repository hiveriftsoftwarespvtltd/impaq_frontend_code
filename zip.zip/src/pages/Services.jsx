import React from 'react'
import {
  Settings, Zap, Building2, Wrench, FileText, Briefcase,
  Search, Headphones, Users, BadgeCheck, TrendingUp
} from 'lucide-react'
import SectionTag from '../components/SectionTag'
import SectionHeading from '../components/SectionHeading'
import ServiceCard from '../components/ServiceCard'
import ProcessStep from '../components/ProcessStep'
import CTABanner from '../components/CTABanner'

const services = [
  {
    icon: Settings,
    title: 'Mechanical Design Engineering',
    description: '3D modeling, machine design, assembly & detailing using SolidWorks, Inventor, Creo and more.',
    linkLabel: 'Learn More',
  },
  {
    icon: Zap,
    title: 'Industrial Automation Support',
    description: 'Electrical design, control systems, PLC, HMI & SCADA support for automation projects.',
    linkLabel: 'Learn More',
  },
  {
    icon: Building2,
    title: 'Structural Engineering & Tekla',
    description: 'Tekla modeling, structural detailing, shop drawings, BOMs and connection design for steel structures.',
    linkLabel: 'Learn More',
  },
  {
    icon: Wrench,
    title: 'Manufacturing Support',
    description: 'Manufacturing drawings, BOM, process planning, Jigs & fixtures and technical support.',
    linkLabel: 'Learn More',
  },
  {
    icon: FileText,
    title: 'Technical Documentation',
    description: 'User manuals, assembly instructions, datasheets, service manuals and more.',
    linkLabel: 'Learn More',
  },
  {
    icon: Briefcase,
    title: 'Project Based Support',
    description: 'End-to-end engineering support for your critical projects and tight deadlines.',
    linkLabel: 'Learn More',
  },
  {
    icon: Search,
    title: 'Engineering Analysis Support',
    description: 'FEA, stress analysis, CFD and other engineering simulations for accurate decision making.',
    linkLabel: 'Learn More',
  },
  {
    icon: Headphones,
    title: 'Other Engineering Support',
    description: 'Reverse engineering, design optimization, CAD conversion and ongoing technical assistance.',
    linkLabel: 'Learn More',
  },
]

const processSteps = [
  { icon: Users, title: 'Understand', description: 'We understand your requirements and project goals.' },
  { icon: BadgeCheck, title: 'Select', description: 'We find and present the right engineering talent for your needs.' },
  { icon: FileText, title: 'Onboard', description: 'Smooth onboarding and tool access setup.' },
  { icon: Settings, title: 'Collaborate', description: 'Engineers work as part of your extended team.' },
  { icon: TrendingUp, title: 'Deliver & Grow', description: 'Consistent delivery & continuous improvement to help you grow.' },
]

export default function Services() {
  return (
    <div>
      {/* ── HERO ── */}
      <section className="relative bg-white overflow-hidden min-h-[400px] lg:min-h-[480px] flex items-center">
        {/* Right image with gradient overlay */}
        <div className="absolute right-0 top-0 bottom-0 w-full lg:w-[65%] z-0">
          <img
            src="https://images.unsplash.com/photo-1573164574511-73c773193279?w=1000&h=600&fit=crop&auto=format"
            alt="Remote engineering team"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-white via-white/80 to-transparent lg:via-white/40" />
          <div className="absolute inset-0 bg-white/40 lg:hidden" /> {/* Mobile overlay */}
        </div>

        <div className="max-w-7xl mx-auto px-6 lg:px-8 relative z-10 w-full">
          <div className="flex flex-col lg:flex-row items-center py-16 lg:py-20">
            {/* Left text */}
            <div className="lg:w-[55%] animate-fade-in-up">
              <p className="text-[11px] lg:text-xs font-bold tracking-[0.2em] text-[#E32B2B] uppercase mb-4">
                SERVICES
              </p>
              <h1 className="text-4xl lg:text-[54px] font-serif font-bold text-[#0E1525] leading-tight mb-6">
                Dedicated Remote<br />Engineering Services
              </h1>
              <div className="w-12 h-[3px] bg-[#E32B2B] rounded-full mb-6" />
              <p className="text-[13px] lg:text-[14px] font-medium text-gray-700 leading-relaxed max-w-[480px] mb-8">
                Impaqwerk provides highly skilled remote engineering professionals who work exclusively for your company and projects. We help engineering companies increase capacity, reduce hiring pressure, and accelerate project execution.
              </p>
              
              <div className="flex flex-wrap gap-6 lg:gap-8">
                {[
                  { icon: Users, label: 'Dedicated\nProfessionals' },
                  { icon: BadgeCheck, label: 'Exclusive\nEngagement' },
                  { icon: TrendingUp, label: 'Scalable Engineering\nCapacity' },
                ].map(({ icon: Icon, label }, idx) => (
                  <div key={idx} className="flex items-start gap-2.5">
                    <Icon className="w-6 h-6 text-[#E32B2B] mt-0.5" strokeWidth={1.5} />
                    <span className="text-[11px] font-bold text-[#0E1525] leading-[1.3] whitespace-pre-line">
                      {label}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── SERVICE AREAS ── */}
      <section className="py-10 lg:py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4 lg:px-8">
          <div className="text-center mb-12">
            <p className="text-[11px] lg:text-xs font-bold tracking-[0.2em] text-[#E32B2B] uppercase mb-4">
              OUR SERVICE AREAS
            </p>
            <h2 className="text-[32px] lg:text-[40px] font-serif font-bold text-[#0E1525] leading-tight mb-5">
              Engineering Expertise. Delivered Remotely.
            </h2>
            <div className="w-12 h-[3px] bg-[#E32B2B] rounded-full mx-auto" />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {services.map((s, i) => (
              <ServiceCard key={i} {...s} />
            ))}
          </div>
        </div>
      </section>

      {/* ── HOW WE WORK ── */}
      <section className="py-10 lg:py-12 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 lg:px-8">
          <div className="text-center mb-14 lg:mb-16">
            <p className="text-[11px] lg:text-xs font-bold tracking-[0.2em] text-[#E32B2B] uppercase mb-4">
              HOW WE WORK
            </p>
            <h2 className="text-[28px] lg:text-[34px] font-serif font-bold text-[#0E1525] leading-tight">
              A Simple Process. Strong Results.
            </h2>
          </div>
          <div className="grid grid-cols-2 lg:grid-cols-5 gap-8 lg:gap-4">
            {processSteps.map((step, i) => (
              <ProcessStep
                key={i}
                {...step}
                step={i + 1}
                isLast={i === processSteps.length - 1}
              />
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA ── */}
      <CTABanner
        title="Need More Engineering Capacity?"
        subtitle="Let's build your remote engineering team and take your projects forward faster."
      />
    </div>
  )
}
